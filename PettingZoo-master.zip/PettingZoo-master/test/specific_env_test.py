from pettingzoo.classic.chess.test_chess import test_chess


def specific_env_tests():
    test_chess.test_chess()
