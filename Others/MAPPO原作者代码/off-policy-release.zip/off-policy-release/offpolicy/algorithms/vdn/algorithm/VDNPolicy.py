from offpolicy.algorithms.qmix.algorithm.QMixPolicy import QMixPolicy

class VDNPolicy(QMixPolicy):
    """See parent class."""
    pass
