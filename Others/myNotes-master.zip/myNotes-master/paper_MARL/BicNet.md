# 2.3 交流-BicNet

paper: [Multiagent Bidirectionally-Coordinated Nets: Emergence of Human-level Coordination in Learning to Play StarCraft Combat Games](https://arxiv.org/abs/1703.10069)

阿里环境: [gym-starcraft](https://github.com/alibaba/gym-starcraft)
