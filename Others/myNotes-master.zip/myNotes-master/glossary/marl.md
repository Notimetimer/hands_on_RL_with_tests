# MARL

- centralized critic and decentralized policy. 使用局部观察训练每个智能体的策略网络, 集中式critic用于定量分析智能体之间的不同
- 