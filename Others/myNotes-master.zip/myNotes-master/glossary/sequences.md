# 英文句子句式记录总结

## 句子
Such large action spaces are difficult to explore efficiently, and thus successfully training DQN-like networks in this context is likely intractable.


## 单词

- intractable - 棘手的

## 短语

- the curse of dimensionality - 维度诅咒 (the number of actions increases exponentially with the number of degrees of freedom. )