# 4.0 探索-自博弈-课程学习

paper:[Emergent Complexity via Multi-Agent Competition]()

相关博客:[左右互搏, self-play, Emergent Complexity via Multi-Agent Competition](https://zhuanlan.zhihu.com/p/32528578?utm_source=wechat_session)
