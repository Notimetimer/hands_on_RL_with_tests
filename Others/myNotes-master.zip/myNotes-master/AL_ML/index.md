# ML

- [深入理解L1/L2正则化](https://www.cnblogs.com/zingp/p/10375691.html)