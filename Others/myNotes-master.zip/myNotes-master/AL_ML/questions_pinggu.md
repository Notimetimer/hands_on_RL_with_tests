# 0 ML-评估指标

<div style="text-align: center; width: 80%; margin: auto; ">
<img width=100% src="img/2021_09_29_10_28_09.png">
</div>

<div style="text-align: center; width: 80%; margin: auto; ">
<img width=100% src="img/2021_09_29_10_30_49.png">
</div>

<div style="text-align: center; width: 80%; margin: auto; ">
<img width=100% src="img/2021_09_29_10_28_17.png">
</div>

<div style="text-align: center; width: 80%; margin: auto; ">
<img width=100% src="img/2021_09_29_10_28_27.png">
</div>

<div style="text-align: center; width: 80%; margin: auto; ">
<img width=100% src="img/2021_09_29_10_29_23.png">
</div>
